package com.example.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Round1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
