package com.example.Project;


import java.util.*;
public class SlotBooked {
    public static void main(String []args) {
        VaccinationCenter vac1 = new VaccinationCenter("Karnatka", "Banglore", "VC1");
        VaccinationCenter vac2 = new VaccinationCenter("Karnatka", "Mysore", "VC2");
        List<VaccinationCenter> v = new ArrayList<>();
        v.add(vac1);
        v.add(vac2);
        User u1 = new User("U1", "Anshu", "Female", 23, "Banglore", "Karnatka");
        User u2 = new User("U2", "Vishal", "Male", 24, "Banglore", "Karnatka");
        List<User> allusers = new ArrayList<>();
        allusers.add(u1);
        allusers.add(u2);
        Capacity c1 = new Capacity(1, 1, "U1");
        Capacity c2 = new Capacity(1, 5, "U2");
        List<Capacity> c = new ArrayList<>();
        c.add(c1);
        c.add(c2);
    }
}
