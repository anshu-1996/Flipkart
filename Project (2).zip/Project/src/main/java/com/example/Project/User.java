package com.example.Project;


import lombok.Getter;
import lombok.Setter;
import lombok.EqualsAndHashCode;

@Getter
@Setter
@EqualsAndHashCode
public class User {
    String identification_no;
    String name;
    String gender;
    int age;
    String district;
    String state;

    User(String identification_no,String name,String gender,int age,String district,String state){
        this.identification_no=identification_no;
        this.name=name;
        this.gender=gender;
        this.age=age;
        this.district=district;
        this.state=state;
    }
}
