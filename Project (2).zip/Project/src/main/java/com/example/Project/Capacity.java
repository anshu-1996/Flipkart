package com.example.Project;


import lombok.Getter;
import lombok.Setter;
import lombok.EqualsAndHashCode;

@Getter
@Setter
@EqualsAndHashCode
public class Capacity {
    int day;
    int capacity;
    String centre_id;

    Capacity(int day,int capacity,String centre_id){
        this.day=day;
        this.capacity=capacity;
        this.centre_id=centre_id;
    }
}
