package com.example.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Round1Application {

	public static void main(String[] args) {
		SpringApplication.run(Round1Application.class, args);
	}

}
