package com.example.Project;


import lombok.Getter;
import lombok.Setter;
import lombok.EqualsAndHashCode;

@Getter
@Setter
@EqualsAndHashCode
public class BookVaccination {
    String user_id;
    String centre_id;
    int day;
    int age;

    BookVaccination(String user_id,String centre_id,int day,int age){
        this.user_id=user_id;
        this.centre_id=centre_id;
        this.day=day;
        this.age=age;

    }
    public void Bookingslot(){
        while(day==1){
        if(age>18){

        }

        }
    }


}
