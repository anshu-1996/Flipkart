package com.example.Project;


import lombok.Getter;
import lombok.Setter;
import lombok.EqualsAndHashCode;

@Getter
@Setter
@EqualsAndHashCode
public class VaccinationCenter {
    String state;
    String district;
    String centre_id;

    VaccinationCenter(String state,String district,String centre_id){
        this.state=state;
        this.district=district;
        this.centre_id=centre_id;
    }
}
