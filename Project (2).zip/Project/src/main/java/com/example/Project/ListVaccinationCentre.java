package com.example.Project;


import lombok.Getter;
import lombok.Setter;
import lombok.EqualsAndHashCode;

import java.util.List;

@Getter
@Setter
@EqualsAndHashCode
public class ListVaccinationCentre {
    private List<Capacity>centre;
    String district;
    ListVaccinationCentre(List<Capacity>centre,String district){
        this.centre=centre;
        this.district=district;
    }
}
